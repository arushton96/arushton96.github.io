from machine import UART
import time

# ==== UART Setup ====
uart = UART(1, baudrate=9600, tx=43, rx=44)  # Adjust pins as needed

# ==== Hardcoded Messages ====
msg1 = bytes([0x41, 0x01, 0x04, 0x01, 0x42])
msg2 = bytes([0x41, 0x01, 0x04, 0x00, 0x42])

# ==== Send Loop ====
while True:
    uart.write(msg1)
    print("Sent message 1:", msg1)
    time.sleep(5)

    uart.write(msg2)
    print("Sent message 2:", msg2)
    time.sleep(5)
